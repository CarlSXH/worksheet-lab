mhpLaTeX
========

LaTeX-based framework for preparing scientific-technical documents
